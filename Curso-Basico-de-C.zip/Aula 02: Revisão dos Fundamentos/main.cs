using System;

// Se a classe Pessoa está dentro de um namespace, importe-o
using MeuProjeto;

class Program
{
    static void Main()
    {
        // Criando um objeto Pessoa
        Pessoa pessoa1 = new Pessoa("João", 30, "Rua das Flores, 123");

        // Exibindo as informações da pessoa
        pessoa1.ExibirInformacoes();
    }
}
