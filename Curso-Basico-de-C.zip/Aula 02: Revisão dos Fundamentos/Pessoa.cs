// Namespace opcional, pode ser omitido se preferir
 namespace MeuProjeto
{
    public class Pessoa
    {
        // Propriedades da classe Pessoa
        public string Nome { get; set; }
        public int Idade { get; set; }
        public string Endereco { get; set; }

        // Construtor da classe Pessoa
        public Pessoa(string nome, int idade, string endereco)
        {
            Nome = nome;
            Idade = idade;
            Endereco = endereco;
        }

        // Método para exibir informações da Pessoa
        public void ExibirInformacoes()
        {
            System.Console.WriteLine($"Nome: {Nome}");
            System.Console.WriteLine($"Idade: {Idade}");
            System.Console.WriteLine($"Endereço: {Endereco}");
        }
    }
}
